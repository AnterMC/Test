<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class AntiTrapper extends Item implements Listener {

    private string $cooldownName = "AntiTrapper";
    private int $cooldownTime = 20;
    private array $immobilizedPlayers = [];

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::BONE));
        $this->setCustomName(TextFormat::GOLD . 'AntiTrapper');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Prevents enemies from building, breaking blocks, or interacting with doors/fences for 10 seconds after being hit.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $target = $event->getEntity();

        if ($damager instanceof Player && $target instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();
            if ($item->equals($this)) {
                $damagerName = strtolower($damager->getName());
                if (AbilityLoader::getInstance()->inCooldown($damagerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($damagerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "AntiTrapper is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $targetName = strtolower($target->getName());
                $this->immobilizedPlayers[$targetName] = time();
                $damager->sendMessage(TextFormat::GREEN . "Enemies cannot build, break blocks, or interact with doors/fences for 10 seconds!");

                AbilityLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($targetName): void {
                    unset($this->immobilizedPlayers[$targetName]);
                }), 20 * 10);

                AbilityLoader::getInstance()->addCooldown($damagerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));
            }
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        if (isset($this->immobilizedPlayers[$playerName]) && $this->immobilizedPlayers[$playerName] + 10 > time()) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You cannot break blocks right now!");
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        if (isset($this->immobilizedPlayers[$playerName]) && $this->immobilizedPlayers[$playerName] + 10 > time()) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You cannot place blocks right now!");
        }
    }
}
