<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class GuardianAngel extends Item implements Listener {

    private string $cooldownName = "GuardianAngel";
    private int $cooldownTime = 30;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::CLOCK));
        $this->setCustomName(TextFormat::GOLD . 'Guardian Angel');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Fully restores your health if you have 4 hearts or less',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '30s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "Guardian Angel is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            $currentHealth = $player->getHealth();
            $maxHealth = $player->getMaxHealth();
            $fourHearts = $maxHealth / 2;

            if ($currentHealth <= $fourHearts) {
                $player->setHealth($maxHealth);

                $player->sendMessage(TextFormat::GREEN . "Your health has been fully restored!");
                AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

                $player->getInventory()->removeItem($this->setCount(1));
            } else {
                $player->sendMessage(TextFormat::RED . "You cannot use Guardian Angel because you have more than 4 hearts!");
            }
        }
    }
}
