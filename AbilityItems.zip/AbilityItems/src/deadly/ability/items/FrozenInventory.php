<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\scheduler\ClosureTask;

class FrozenInventory extends Item implements Listener {

    private string $cooldownName = "FrozenInventory";
    private int $cooldownTime = 20;
    private array $frozenPlayers = [];

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::STICK));
        $this->setCustomName(TextFormat::GOLD . 'FrozenInventory');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Prevents the enemy from moving items in their inventory, dropping items, or picking up items for 5 seconds.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $target = $event->getEntity();

        if ($damager instanceof Player && $target instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();
            if ($item->equals($this)) {
                $damagerName = strtolower($damager->getName());
                if (AbilityLoader::getInstance()->inCooldown($damagerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($damagerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "FrozenInventory is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $targetName = strtolower($target->getName());
                $this->frozenPlayers[$targetName] = time();

                $damager->sendMessage(TextFormat::GREEN . "The enemy's inventory has been frozen for 5 seconds!");

                AbilityLoader::getInstance()->addCooldown($damagerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));

                AbilityLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($targetName): void {
                    unset($this->frozenPlayers[$targetName]);
                }), 20 * 5);
            }
        }
    }

    public function onPlayerDropItem(PlayerDropItemEvent $event): void {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        if (isset($this->frozenPlayers[$playerName])) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You cannot drop items right now!");
        }
    }

    public function onPlayerPickupItem(EntityItemPickupEvent $event): void {
        $player = $event->getEntity();
        $playerName = strtolower($player->getName());

        if (isset($this->frozenPlayers[$playerName])) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You cannot pick up items right now!");
        }
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void {
        $player = $event->getTransaction()->getSource();
        $playerName = strtolower($player->getName());

        if (isset($this->frozenPlayers[$playerName])) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You cannot change items in your inventory right now!");
        }
    }
}
