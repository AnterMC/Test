<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class TimeStone extends Item implements Listener {

    private string $cooldownName = "TimeStone";
    private int $cooldownTime = 60;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::SLIMEBALL));
        $this->setCustomName(TextFormat::GOLD . 'Time Stone');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Removes all active cooldowns but adds a cooldown for itself',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '60s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "Time Stone is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            AbilityLoader::getInstance()->removeAllCooldowns($playerName);
            AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

            $player->sendMessage(TextFormat::GREEN . "All active cooldowns have been removed, but Time Stone is now on cooldown for 60 seconds!");

            $player->getInventory()->removeItem($this->setCount(1));
        }
    }
}
