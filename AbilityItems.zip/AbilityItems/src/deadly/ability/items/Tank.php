<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class Tank extends Item implements Listener {

    private string $cooldownName = "Tank";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::IRON_INGOT));
        $this->setCustomName(TextFormat::GOLD . 'Tank');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Grants Resistance 3 for 5 seconds.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "Tank is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            $player->getEffects()->add(new EffectInstance(VanillaEffects::RESISTANCE(), 100, 2));

            $player->sendMessage(TextFormat::GREEN . "You have been granted Resistance 3 for 5 seconds!");
            AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

            $player->getInventory()->removeItem($this->setCount(1));
        }
    }
}
