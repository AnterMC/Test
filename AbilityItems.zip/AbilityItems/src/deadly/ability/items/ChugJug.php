<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\PotionType;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class ChugJug extends Item implements Listener {

    private string $cooldownName = "ChugJug";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::GLASS_BOTTLE));
        $this->setCustomName(TextFormat::GOLD . 'Chug Jug');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Fills all empty inventory slots with Splash Potions of Instant Health II.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "Chug Jug is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            $splashPotion = VanillaItems::SPLASH_POTION()->setType(PotionType::STRONG_HEALING);

            $inventory = $player->getInventory();
            foreach ($inventory->getContents() as $index => $item) {
                if ($item->isNull()) {
                    $inventory->setItem($index, $splashPotion);
                }
            }

            $player->sendMessage(TextFormat::GREEN . "All empty inventory slots have been filled with Splash Potions of Instant Health II!");

            AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

            $player->getInventory()->removeItem($this->setCount(1));
        }
    }
}
