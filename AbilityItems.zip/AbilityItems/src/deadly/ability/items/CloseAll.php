<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class CloseAll extends Item implements Listener {

    private string $cooldownName = "CloseAll";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::COOKIE));
        $this->setCustomName(TextFormat::GOLD . 'CloseAll');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Grants Resistance 3, Regeneration 5, and Strength 2 for 6 seconds if you have 4 hearts or less',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "CloseAll is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            $currentHealth = $player->getHealth();
            $maxHealth = $player->getMaxHealth();
            $fourHearts = $maxHealth / 2;

            if ($currentHealth <= $fourHearts) {
                $player->getEffects()->add(new EffectInstance(VanillaEffects::RESISTANCE(), 120, 2));
                $player->getEffects()->add(new EffectInstance(VanillaEffects::REGENERATION(), 120, 4));
                $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 120, 1));

                $player->sendMessage(TextFormat::GREEN . "You have been granted Resistance 3, Regeneration 5, and Strength 2 for 6 seconds!");
                AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

                $player->getInventory()->removeItem($this->setCount(1));
            } else {
                $player->sendMessage(TextFormat::RED . "You cannot use CloseAll because you have more than 4 hearts!");
            }
        }
    }
}
