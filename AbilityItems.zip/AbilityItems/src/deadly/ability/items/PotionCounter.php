<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\PotionType;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class PotionCounter extends Item implements Listener {

    private string $cooldownName = "PotionCounter";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::BONE));
        $this->setCustomName(TextFormat::GOLD . 'PotionCounter');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Counts the total number of potions in the enemy\'s inventory when you hit them.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $target = $event->getEntity();

        if ($damager instanceof Player && $target instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();
            if ($item->equals($this)) {
                $damagerName = strtolower($damager->getName());
                if (AbilityLoader::getInstance()->inCooldown($damagerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($damagerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "PotionCounter is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $targetInventory = $target->getInventory();
                $totalPotions = 0;

                foreach ($targetInventory->getContents() as $item) {
                    if ($item->getId() === ItemTypeIds::SPLASH_POTION || $item->getTypeId() === VanillaItems::SPLASH_POTION()->getType()->equals(PotionType::STRONG_HEALING())) {
                        $totalPotions += $item->getCount();
                    }
                }

                $damager->sendMessage(TextFormat::YELLOW . "The enemy has a total of $totalPotions potions in their inventory.");

                AbilityLoader::getInstance()->addCooldown($damagerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));
            }
        }
    }
}
