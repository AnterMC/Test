<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class HotbarScrambler extends Item implements Listener {

    private string $cooldownName = "HotbarScrambler";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::BLAZE_ROD));
        $this->setCustomName(TextFormat::GOLD . 'Hotbar Scrambler');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Randomly scrambles the items in the first 9 slots of the enemy\'s hotbar.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $target = $event->getEntity();

        if ($damager instanceof Player && $target instanceof Player) {
            $itemInHand = $damager->getInventory()->getItemInHand();

            if ($itemInHand->equals($this)) {
                $targetName = strtolower($target->getName());
                $damagerName = strtolower($damager->getName());

                if (AbilityLoader::getInstance()->inCooldown($damagerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($damagerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "Hotbar Scrambler is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $hotbarItems = $target->getInventory()->getContents();
                $hotbarItems = array_slice($hotbarItems, 0, 9);

                $shuffledItems = $hotbarItems;
                shuffle($shuffledItems);

                foreach ($shuffledItems as $index => $item) {
                    $target->getInventory()->setItem($index, $item);
                }

                $damager->sendMessage(TextFormat::GREEN . "You scrambled the hotbar of " . $target->getName() . "!");

                AbilityLoader::getInstance()->addCooldown($damagerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));
            }
        }
    }
}
