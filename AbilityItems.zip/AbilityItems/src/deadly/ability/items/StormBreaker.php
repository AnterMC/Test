<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class StormBreaker extends Item implements Listener {

    private string $cooldownName = "StormBreaker";
    private int $cooldownTime = 20;

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::GOLDEN_AXE));
        $this->setCustomName(TextFormat::GOLD . 'Storm Breaker');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Swap the helmet with the item in hand of the target when hit',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $entity = $event->getEntity();

        if ($damager instanceof Player && $entity instanceof Player) {
            $playerName = strtolower($damager->getName());
            $itemInHand = $damager->getInventory()->getItemInHand();

            if ($itemInHand->equals($this)) {
                if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "Storm Breaker is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $targetArmor = $entity->getArmorInventory();
                $targetHelmet = $targetArmor->getHelmet();
                $targetItemInHand = $entity->getInventory()->getItemInHand();

                $targetArmor->setHelmet($targetItemInHand);
                $entity->getInventory()->setItemInHand($targetHelmet);

                $damager->sendMessage(TextFormat::GREEN . "Successfully swapped " . $entity->getName() . "'s helmet and item in hand!");

                AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));
            }
        }
    }
}
