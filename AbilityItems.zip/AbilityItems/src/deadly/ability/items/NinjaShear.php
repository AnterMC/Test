<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;

class NinjaShear extends Item implements Listener {

    private string $cooldownName = "NinjaShear";
    private int $cooldownTime = 20;
    private array $lastHit = [];

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::SHEARS));
        $this->setCustomName(TextFormat::GOLD . 'Ninja Shear');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Teleport to the position of the last player who hit you 15 seconds ago',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamage(EntityDamageByEntityEvent $event): void {
        $entity = $event->getEntity();
        $damager = $event->getDamager();

        if ($entity instanceof Player && $damager instanceof Player) {
            $playerName = strtolower($entity->getName());
            $damagerPosition = $damager->getPosition();

            $this->lastHit[$playerName] = [
                "position" => $damagerPosition,
                "attacker" => $damager->getName(),
                "time" => time()
            ];

            AbilityLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($playerName): void {
                unset($this->lastHit[$playerName]);
            }), 20 * 15);
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->equals($this)) {
            $playerName = strtolower($player->getName());

            if (AbilityLoader::getInstance()->inCooldown($playerName, $this->cooldownName)) {
                $timeLeft = AbilityLoader::getInstance()->getCooldown($playerName, $this->cooldownName);
                $player->sendMessage(TextFormat::RED . "Ninja Shear is on cooldown! Time left: $timeLeft seconds.");
                return;
            }

            if (isset($this->lastHit[$playerName])) {
                $data = $this->lastHit[$playerName];
                $attackerPosition = $data["position"];

                if ($player->getPosition()->distance($attackerPosition) <= 10) {
                    $player->sendMessage(TextFormat::YELLOW . "Teleporting in 5 seconds... stay still.");

                    AbilityLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player, $attackerPosition): void {
                        $player->teleport($attackerPosition);
                        $player->sendMessage(TextFormat::GREEN . "You have been teleported to the attacker!");
                    }), 20 * 5);

                    $player->getInventory()->removeItem($this->setCount(1));

                    AbilityLoader::getInstance()->addCooldown($playerName, $this->cooldownName, $this->cooldownTime);
                } else {
                    $player->sendMessage(TextFormat::RED . "The attacker is too far away!");
                }
            } else {
                $player->sendMessage(TextFormat::RED . "You have no registered attacker!");
            }
        }
    }
}
