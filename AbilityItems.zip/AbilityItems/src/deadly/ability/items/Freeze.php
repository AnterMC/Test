<?php

namespace deadly\ability\items;

use deadly\ability\AbilityLoader;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\scheduler\ClosureTask;

class Freeze extends Item implements Listener {

    private string $cooldownName = "Freeze";
    private int $cooldownTime = 20;
    private array $frozenPlayers = [];

    public function __construct() {
        parent::__construct(new ItemIdentifier(ItemTypeIds::CLAY));
        $this->setCustomName(TextFormat::GOLD . 'Freeze');
        $this->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING()));
        $this->setLore([
            TextFormat::DARK_GRAY . 'Freezes the enemy for 3 seconds, preventing them from moving.',
            TextFormat::GRAY . 'Cooldown: ' . TextFormat::GOLD . '20s'
        ]);
        Server::getInstance()->getPluginManager()->registerEvents($this, AbilityLoader::getInstance());
    }

    public function onEntityDamageByEntity(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        $target = $event->getEntity();

        if ($damager instanceof Player && $target instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();
            if ($item->equals($this)) {
                $damagerName = strtolower($damager->getName());
                if (AbilityLoader::getInstance()->inCooldown($damagerName, $this->cooldownName)) {
                    $timeLeft = AbilityLoader::getInstance()->getCooldown($damagerName, $this->cooldownName);
                    $damager->sendMessage(TextFormat::RED . "Freeze is on cooldown! Time left: $timeLeft seconds.");
                    return;
                }

                $targetName = strtolower($target->getName());
                $this->frozenPlayers[$targetName] = time();

                $damager->sendMessage(TextFormat::GREEN . "The enemy has been frozen for 3 seconds!");

                AbilityLoader::getInstance()->addCooldown($damagerName, $this->cooldownName, $this->cooldownTime);

                $damager->getInventory()->removeItem($this->setCount(1));

                AbilityLoader::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($targetName): void {
                    unset($this->frozenPlayers[$targetName]);
                }), 20 * 3);
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        if (isset($this->frozenPlayers[$playerName])) {
            $event->cancel();
            $player->sendMessage(TextFormat::RED . "You are frozen and cannot move!");
        }
    }
}
