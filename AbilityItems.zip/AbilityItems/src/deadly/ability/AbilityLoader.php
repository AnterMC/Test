<?php

declare(strict_types=1);

namespace deadly\ability;

use deadly\ability\command\AbilityCommand;
use deadly\ability\items\AntiTrapper;
use deadly\ability\items\ChugJug;
use deadly\ability\items\CloseAll;
use deadly\ability\items\Freeze;
use deadly\ability\items\FrozenInventory;
use deadly\ability\items\GuardianAngel;
use deadly\ability\items\HotbarScrambler;
use deadly\ability\items\NinjaShear;
use deadly\ability\items\PotionCounter;
use deadly\ability\items\RiskyMode;
use deadly\ability\items\StormBreaker;
use deadly\ability\items\Strength;
use deadly\ability\items\Switcher;
use deadly\ability\items\Tank;
use deadly\ability\items\TimeStone;
use pocketmine\plugin\PluginBase;

class AbilityLoader extends PluginBase {

    private static AbilityLoader $instance;

    private array $cooldowns = [];

    public function onEnable(): void {
        self::$instance = $this;
        $this->registerListeners();
        $this->getServer()->getCommandMap()->register("ability", new AbilityCommand());
        $this->getLogger()->info("AbilityLoader initialized!");
    }

    public static function getInstance(): AbilityLoader {
        return self::$instance;
    }

    public function addCooldown(string $playerName, string $cooldownName, int $seconds): void {
        $this->cooldowns[strtolower($playerName)][$cooldownName] = time() + $seconds;
    }

    public function getCooldown(string $playerName, string $cooldownName): ?int {
        $playerName = strtolower($playerName);

        if (isset($this->cooldowns[$playerName][$cooldownName])) {
            $timeLeft = $this->cooldowns[$playerName][$cooldownName] - time();
            return $timeLeft > 0 ? $timeLeft : null;
        }

        return null;
    }

    public function inCooldown(string $playerName, string $cooldownName): bool {
        return $this->getCooldown($playerName, $cooldownName) !== null;
    }

    public function removeAllCooldowns(string $playerName): void {
        $playerName = strtolower($playerName);

        if (isset($this->cooldowns[$playerName])) {
            unset($this->cooldowns[$playerName]);
        }
    }

    private function registerListeners(): void
    {
        new AntiTrapper();
        new ChugJug();
        new CloseAll();
        new Freeze();
        new FrozenInventory();
        new GuardianAngel();
        new HotbarScrambler();
        new NinjaShear();
        new PotionCounter();
        new RiskyMode();
        new StormBreaker();
        new Strength();
        new Tank();
        new TimeStone();
    }
}
