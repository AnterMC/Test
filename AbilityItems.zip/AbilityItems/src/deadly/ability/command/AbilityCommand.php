<?php

namespace deadly\ability\command;

use deadly\ability\items\CloseAll;
use deadly\ability\items\GuardianAngel;
use deadly\ability\items\NinjaShear;
use deadly\ability\items\StormBreaker;
use deadly\ability\items\Switcher;
use deadly\ability\items\TimeStone;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use deadly\ability\items\AntiTrapper;
use deadly\ability\items\HotbarScrambler;
use deadly\ability\items\ChugJug;
use deadly\ability\items\PotionCounter;
use deadly\ability\items\Freeze;
use deadly\ability\items\FrozenInventory;
use deadly\ability\items\RiskyMode;
use deadly\ability\items\Tank;
use deadly\ability\items\Strength;

class AbilityCommand extends Command {

    public function __construct() {
        parent::__construct("ability", "Give all Abilities", "/ability", ["partneritems","abilites", "pitems"]);
        $this->setPermission("ability.command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "This command can only be used by players.");
            return false;
        }

        $items = [
            new AntiTrapper(),
            new ChugJug(),
            new CloseAll(),
            new Freeze(),
            new FrozenInventory(),
            new GuardianAngel(),
            new HotbarScrambler(),
            new NinjaShear(),
            new PotionCounter(),
            new RiskyMode(),
            new StormBreaker(),
            new Strength(),
            new Tank(),
            new TimeStone()
        ];

        foreach ($items as $item) {
            $sender->getInventory()->addItem($item->setCount(1));
        }

        $sender->sendMessage(TextFormat::GREEN . "You have been given all ability items!");

        return true;
    }
}
